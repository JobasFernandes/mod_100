import React, { useState, useContext } from "react";
import Lottie from "react-lottie";

import {
  TextField,
  InputAdornment,
  IconButton,
  CssBaseline,
  Container
} from '@material-ui/core';

import { Visibility, VisibilityOff } from '@material-ui/icons';

import '../../assets/style.css';
import { makeStyles } from "@material-ui/core/styles";
import { i18n } from "../../translate/i18n";

import { AuthContext } from "../../context/Auth/AuthContext";

import animationData from "../../assets/bg.json";
import logo from '../../assets/logo_login.png';

const useStyles = makeStyles(theme => ({
  root: {
    width: "100vw",
    height: "100vh",
    background-color: #0093E9;
    background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
    backgroundRepeat: "no-repeat",
    backgroundSize: "100% 100%",
    backgroundPosition: "center",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
  },
  contentWrapper: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: "40px",
  },
  paper: {
    backgroundColor: "white",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "55px 30px",
    borderRadius: "12.5px",
  }
}));

const Login = () => {
  const classes = useStyles();
  const [user, setUser] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);

  const { handleLogin } = useContext(AuthContext);

  const handleChangeInput = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleLogin(user);
  };

  return (
    <div className={classes.root}>
      <div className={classes.contentWrapper}>
        <div className="img" style={{ marginRight: "200px" }}>
          <Lottie
            options={{
              loop: true,
              autoplay: true,
              animationData: animationData,
              speed: 2.0
            }}
            width={700} // Largura do Lottie aumentada
            speed={2.0} // Velocidad do Lottie
          />
        </div>
        <Container component="main" maxWidth="xs">
          <CssBaseline />
          <div className={classes.paper}>
            <div>
              <img style={{ margin: "0 auto", height: "80px", width: "100%" }} src={logo} alt="Valezap" />
            </div>
            <form noValidate onSubmit={handleSubmit} style={{ display: "grid" }}>
              <TextField
                variant="standard"
                margin="normal"
                color="warning"
                required
                fullWidth
                id="email"
                label={i18n.t("login.form.email")}
                name="email"
                value={user.email}
                onChange={handleChangeInput}
                autoComplete="email"
                autoFocus
              />
              <TextField
                variant="standard"
                margin="normal"
                color="success"
                required
                fullWidth
                name="password"
                label={i18n.t("login.form.password")}
                id="password"
                value={user.password}
                onChange={handleChangeInput}
                autoComplete="current-password"
                type={showPassword ? 'text' : 'password'}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={() => setShowPassword((e) => !e)}
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  )
                }}
              />
              <input type="submit" className="btn" value="Acessar" />
            </form>
          </div>
        </Container>
      </div>
    </div>
  );
};

export default Login;
