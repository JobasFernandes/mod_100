import React, { useState, useContext } from "react";

import {
  TextField,
  InputAdornment,
  IconButton,
  CssBaseline,
  Container,
  Button,
} from "@material-ui/core";

import { Visibility, VisibilityOff } from "@material-ui/icons";

import { makeStyles } from "@material-ui/core/styles";
import { i18n } from "../../translate/i18n";

import { AuthContext } from "../../context/Auth/AuthContext";

import phone from "../../assets/phone.png";
import bgImage from '../../assets/bg.png';
import logo from "../../assets/logo_login.png";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100vw",
    height: "100vh",
    backgroundImage: `url(${bgImage})`,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
  },
  contentWrapper: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: "40px",
    overflowY: "auto",
  },
  paper: {
    backgroundColor: "#FFFFFF",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "55px 30px",
    borderRadius: "12.5px",
    boxShadow: "inset 0 0 4px #1C9F78",
  },
  logo: {
    margin: "0 auto",
    height: "80px",
    width: "100%",
    [theme.breakpoints.down("sm")]: {
      height: "auto",
      width: "100%",
    },
  },
  bgWrapper: {
    marginRight: "30%",
    width: "100%",
    [theme.breakpoints.down("sm")]: {
      display: "none",
    },
  },
  formWrapper: {
    width: "100%",
    display: "grid",
    gap: "10px",
  },
  btn: {
    background: "#1C9F78",
    borderRadius: "25px",
    color: "#FFFFFF",
    fontWeight: "bold",
    marginTop: "10px",
    "&:hover": {
      background: "#FFFFFF",
      color: "#1C9F78",
      boxShadow: "inset 0 0 4px #1C9F78",
    },
  },
}));

const Login = () => {
  const classes = useStyles();
  const [user, setUser] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);

  const { handleLogin } = useContext(AuthContext);

  const handleChangeInput = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleLogin(user);
  };

  return (
    <div className={classes.root}>
      <div className={classes.contentWrapper}>
        <div className={classes.bgWrapper}>
          <img src={phone} style={{ width: "100%" }} />
        </div>
        <Container component="main" maxWidth="xs" className={classes.formWrapper}>
          <CssBaseline />
          <div className={classes.paper}>
            <div>
              <img
                className={classes.logo}
                src={logo}
                alt="Valezap"
              />
            </div>
            <form noValidate onSubmit={handleSubmit}>
              <TextField
                variant="standard"
                margin="normal"
                color="warning"
                required
                fullWidth
                id="email"
                label={i18n.t("login.form.email")}
                name="email"
                value={user.email}
                onChange={handleChangeInput}
                autoComplete="email"
                autoFocus
              />
              <TextField
                variant="standard"
                margin="normal"
                color="success"
                required
                fullWidth
                name="password"
                label={i18n.t("login.form.password")}
                id="password"
                value={user.password}
                onChange={handleChangeInput}
                autoComplete="current-password"
                type={showPassword ? "text" : "password"}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={() => setShowPassword((e) => !e)}
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              <Button
                type="submit"
                className={classes.btn}
                fullWidth
              >
                Acessar
              </Button>
            </form>
          </div>
        </Container>
      </div>
    </div>
  );
};

export default Login;
