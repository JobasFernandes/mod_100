import React, { useState, useEffect } from 'react';
import { Box, Container, Typography, TextField, Tooltip, IconButton } from '@mui/material';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';
import DeleteSweepIcon from '@material-ui/icons/DeleteSweep';
import { makeStyles } from '@mui/styles';
import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd';

const useStyles = makeStyles((theme) => ({
  container: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 25%)',
    gap: '16px',
  },
  column: {
    padding: '16px',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    width: '100%',
    flex: 1,
  },
  deleteIcon: {
    marginLeft: 'auto',
    cursor: 'pointer',
    '&:hover': {
      color: '#FF1744',
    },
  },
  textField: {
    '& .MuiOutlinedInput-root': {
      borderRadius: '8px',
      '&.Mui-focused fieldset': {
        borderColor: '#34BCFF',
      },
    },
  },
}));

const ToDoList = () => {
  const classes = useStyles();

  const initialTasks = {
    Tarefas: [],
    'Em Andamento': [],
    'Em Atraso': [],
    Concluídas: [],
  };

  const columnColors = {
    Tarefas: '#F2F2F2',
    'Em Andamento': '#FFFFCC',
    'Em Atraso': '#FFCCCC',
    Concluídas: '#CCFFCC',
  };

  const [tasks, setTasks] = useState(initialTasks);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDescription, setNewTaskDescription] = useState('');
  const [editTask, setEditTask] = useState(null);

  useEffect(() => {
    const cachedTasks = JSON.parse(localStorage.getItem('todoTasks'));
    if (cachedTasks) {
      setTasks(cachedTasks);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('todoTasks', JSON.stringify(tasks));
  }, [tasks]);

  const onDragEnd = (result) => {
    if (!result.destination) return;

    const sourceColumn = result.source.droppableId;
    const destinationColumn = result.destination.droppableId;
    const taskId = result.draggableId;

    if (sourceColumn !== destinationColumn) {
      setTasks((prevTasks) => {
        const updatedTasks = { ...prevTasks };
        const taskToMove = updatedTasks[sourceColumn].find((task) => task.id === taskId);
        if (taskToMove) {
          updatedTasks[sourceColumn] = updatedTasks[sourceColumn].filter((task) => task.id !== taskId);
          updatedTasks[destinationColumn] = [...updatedTasks[destinationColumn], taskToMove];
          taskToMove.status = destinationColumn;
        }
        return updatedTasks;
      });
    }
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${day}/${month} às ${hours}:${minutes}`;
  };

  const addTask = () => {
    const currentTime = new Date();
    const formattedTime = formatDate(currentTime);

    const newTask = {
      id: Date.now().toString(),
      title: newTaskTitle,
      description: newTaskDescription,
      status: 'Tarefas',
      timestamp: currentTime.toISOString(),
    };
    setTasks((prevTasks) => ({
      ...prevTasks,
      Tarefas: [...prevTasks.Tarefas, newTask],
    }));
    setNewTaskTitle('');
    setNewTaskDescription('');
  };

  const handleTitleChange = (event) => {
    setNewTaskTitle(event.target.value);
  };

  const handleDescriptionChange = (event) => {
    setNewTaskDescription(event.target.value);
  };

  const deleteCompletedTasks = () => {
    setTasks((prevTasks) => ({
      ...prevTasks,
      Concluídas: [],
    }));
  };

  const editTaskHandler = (task) => {
    setNewTaskTitle(task.title);
    setNewTaskDescription(task.description);
    setEditTask(task);
  };

  const updateTaskHandler = () => {
    if (editTask) {
      const updatedTask = {
        ...editTask,
        title: newTaskTitle,
        description: newTaskDescription,
      };
      setTasks((prevTasks) => {
        const updatedTasks = { ...prevTasks };
        updatedTasks[editTask.status] = updatedTasks[editTask.status].map((task) =>
          task.id === updatedTask.id ? updatedTask : task
        );
        return updatedTasks;
      });
    } else {
      addTask();
    }
    setEditTask(null);
    setNewTaskTitle('');
    setNewTaskDescription('');
  };

  const deleteTaskHandler = (taskId) => {
    setTasks((prevTasks) => {
      const updatedTasks = { ...prevTasks };
      Object.keys(updatedTasks).forEach((status) => {
        updatedTasks[status] = updatedTasks[status].filter((task) => task.id !== taskId);
      });
      return updatedTasks;
    });
  };

  const checkElapsedTimeAndMoveToLate = () => {
    setTasks((prevTasks) => {
      const updatedTasks = { ...prevTasks };
      updatedTasks['Em Andamento'].forEach((task) => {
        const creationTime = new Date(task.timestamp).getTime();
        const currentTime = new Date().getTime();
        const elapsedTime = currentTime - creationTime;
        if (elapsedTime >= 3600000) { // Tempo para mudar a tarefa para 'Em Atraso' em milissegundos (1 hora)
          updatedTasks['Em Andamento'] = updatedTasks['Em Andamento'].filter((t) => t.id !== task.id);
          updatedTasks['Em Atraso'].push({ ...task, status: 'Em Atraso' });
        }
      });
      return updatedTasks;
    });
  };

  useEffect(() => {
    const interval = setInterval(checkElapsedTimeAndMoveToLate, 60000); // Verificar a cada minuto
    return () => clearInterval(interval);
  }, []);

  return (
    <Container>
      <Box mt={4} display="flex" flexDirection="row" alignItems="center" gap="16px">
        <TextField
          label="Título da Tarefa"
          variant="outlined"
          value={newTaskTitle}
          onChange={handleTitleChange}
          className={classes.textField}
          style={{ width: '30%' }}
        />
        <TextField
          label="Descrição da Tarefa"
          variant="outlined"
          value={newTaskDescription}
          onChange={handleDescriptionChange}
          className={classes.textField}
          style={{ width: '65%' }}
        />
        <Tooltip title="Adicionar Tarefa">
          <IconButton onClick={updateTaskHandler} style={{ color: 'green' }}>
            <CheckCircleRoundedIcon />
          </IconButton>
        </Tooltip>
      </Box>
      <DragDropContext onDragEnd={onDragEnd}>
        <Box className={classes.container} mt={4} >
          {Object.keys(tasks).map((status) => (
            <Droppable key={status} droppableId={status}>
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className={classes.column}
                  style={{ backgroundColor: columnColors[status] }}
                >
                  <Typography variant="h6">{status}</Typography>
                  {provided.placeholder}
                  {status === 'Concluídas' && tasks['Concluídas'].some((task) => task.status === 'Concluídas') && (
                    <Tooltip title="Excluir concluídas">
                      <DeleteSweepIcon
                        onClick={deleteCompletedTasks}
                        color="error"
                        className={classes.deleteIcon}
                        style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '-30px' }}
                      />
                    </Tooltip>
                  )}
                  {tasks[status].map((task, index) => (
                    <Draggable key={task.id} draggableId={task.id} index={index}>
                      {(provided) => (
                        <Box
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          sx={{
                            width: '100%',
                            mt: 1,
                            backgroundColor: 'transparent',
                            border: '1px solid #ccc',
                            borderRadius: '8px',
                            p: '16px',
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '8px',
                          }}
                          onDoubleClick={() => editTaskHandler(task)}
                        >
                          {editTask === task ? (
                            <>
                              <Typography variant="body1">
                                <strong>{task.title}</strong>
                              </Typography>
                              <Typography variant="body1">{task.description}</Typography>
                              <Typography variant="body2" style={{ justifyContent: "flex-start", alignItems: "flex-end" }}>
                                Criada em: {formatDate(task.timestamp)}
                              </Typography>
                              <Tooltip title="Excluir">
                                <DeleteRoundedIcon
                                  onClick={() => deleteTaskHandler(task.id)}
                                  className={classes.deleteIcon}
                                  style={{ display: "flex", justifyContent: "flex-end", alignItems: "flex-end" }}
                                />
                              </Tooltip>
                            </>
                          ) : (
                            <>
                              <Typography variant="body1">
                                <strong>{task.title}</strong>
                              </Typography>
                              <Typography variant="body1">{task.description}</Typography>
                              <Typography variant="body2" style={{ justifyContent: "flex-start", alignItems: "flex-end" }}>
                                Criada em: {formatDate(task.timestamp)}
                              </Typography>
                              <Tooltip title="Excluir">
                                <DeleteRoundedIcon
                                  onClick={() => deleteTaskHandler(task.id)}
                                  className={classes.deleteIcon}
                                  style={{ display: "flex", justifyContent: "flex-end", alignItems: "flex-end" }}
                                />
                              </Tooltip>
                            </>
                          )}
                        </Box>
                      )}
                    </Draggable>
                  ))}
                </div>
              )}
            </Droppable>
          ))}
        </Box>
      </DragDropContext>
    </Container>
  );
};

export default ToDoList;