import React, { useState, useEffect } from "react";
import qs from 'query-string'

import * as Yup from "yup";
import { useHistory } from "react-router-dom";
import { Link as RouterLink } from "react-router-dom";
import { toast } from "react-toastify";
import { Formik } from "formik";

import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import { TextField, InputAdornment, IconButton, FormHelperText } from '@material-ui/core';
import Link from "@material-ui/core/Link";
import Grid from "@material-ui/core/Grid";
import Box from "@material-ui/core/Box";
import logo from '../../assets/logo_login.png';
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";
import usePlans from '../../hooks/usePlans';
import { i18n } from "../../translate/i18n";
import { FormControl, InputLabel, MenuItem, Select } from "@material-ui/core";
import { Visibility, VisibilityOff } from '@material-ui/icons';

import { openApi } from "../../services/api";
import toastError from "../../errors/toastError";

import Autocomplete from "@material-ui/lab/Autocomplete";

const useStyles = makeStyles(theme => ({
    root: {
        width: "100vw",
        height: "100vh",
        backgroundColor: "#0093E9",
        backgroundImage: "linear-gradient(160deg, #0093E9 0%, #80D0C7 100%)",
        backgroundRepeat: "no-repeat",
        backgroundSize: "100% 100%",
        backgroundPosition: "center",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        overflowY: "auto",
    },
    contentWrapper: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
    },
    paper: {
        backgroundColor: "white",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "40px 30px",
        borderRadius: "12.5px",
        marginTop: "40px",
    },
    form: {
        width: "100%",
        marginTop: theme.spacing(3),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}));

const UserSchema = Yup.object().shape({
    name: Yup.string()
        .min(4, "Muito curto!")
        .max(50, "Muito longo!")
        .required("Obrigatório"),
    companyName: Yup.string()
        .min(4, "Muito curto!")
        .max(50, "Muito longo!")
        .required("Obrigatório"),
    password: Yup.string().min(5, "Senha curta!").max(50, "Senha longa!").required("Obrigatório"),
    email: Yup.string().email("Email inválido").required("Obrigatório"),
    phone: Yup.string()
        .test(
            "phone-validation",
            "Telefone inválido, digite um número de celular com o nono dígito.",
            value => {
                if (value && value.length >= 10 && value.length <= 12) {
                    return /^[0-9]{2,3}[9]{1}[0-9]{8}$/.test(value);
                }
                return false;
            }
        )
        .matches(/^[0-9]+$/, "Só é permitido números")
        .required("Obrigatório"),
    cpfCnpj: Yup.string()
        .test("cpf-cnpj", "CPF/CNPJ Inválido", value => isValidCpf(value) || isValidCnpj(value))
        .required("Obrigatório"),
});

function isValidCpf(cpf) {
    cpf = cpf.replace(/[^\d]+/g, ''); // Remove characters que não são dígitos

    if (cpf.length !== 11) {
        return false;
    }

    // Verifica se todos os dígitos são iguais (ex: 111.111.111-11)
    if (/^(\d)\1+$/.test(cpf)) {
        return false;
    }

    // Validação do primeiro dígito verificador
    let sum = 0;
    for (let i = 0; i < 9; i++) {
        sum += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let remainder = sum % 11;
    let digit = (remainder < 2) ? 0 : 11 - remainder;
    if (parseInt(cpf.charAt(9)) !== digit) {
        return false;
    }

    // Validação do segundo dígito verificador
    sum = 0;
    for (let i = 0; i < 10; i++) {
        sum += parseInt(cpf.charAt(i)) * (11 - i);
    }
    remainder = sum % 11;
    digit = (remainder < 2) ? 0 : 11 - remainder;
    if (parseInt(cpf.charAt(10)) !== digit) {
        return false;
    }

    return true;
}

function isValidCnpj(cnpj) {
    cnpj = cnpj.replace(/[^\d]+/g, ''); // Remove characters que não são dígitos

    if (cnpj.length !== 14) {
        return false;
    }

    // Verifica se todos os dígitos são iguais (ex: 00.000.000/0000-00)
    if (/^(\d)\1+$/.test(cnpj)) {
        return false;
    }

    // Validação do primeiro dígito verificador
    let sum = 0;
    let weight = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    for (let i = 0; i < 12; i++) {
        sum += parseInt(cnpj.charAt(i)) * weight[i];
    }
    let remainder = sum % 11;
    let digit = (remainder < 2) ? 0 : 11 - remainder;
    if (parseInt(cnpj.charAt(12)) !== digit) {
        return false;
    }

    // Validação do segundo dígito verificador
    sum = 0;
    weight = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    for (let i = 0; i < 13; i++) {
        sum += parseInt(cnpj.charAt(i)) * weight[i];
    }
    remainder = sum % 11;
    digit = (remainder < 2) ? 0 : 11 - remainder;
    if (parseInt(cnpj.charAt(13)) !== digit) {
        return false;
    }

    return true;
}

const SignUp = () => {
    const classes = useStyles();
    const history = useHistory();
    const { getPlanList } = usePlans()
    const [plans, setPlans] = useState([])
    const [loading, setLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState("");

    let companyId = null
    const params = qs.parse(window.location.search)
    if (params.companyId !== undefined) {
        companyId = params.companyId
    }

    const initialState = { name: "", email: "", password: "", phone: "", companyId, companyName: "", planId: "", cpfCnpj: "" };
    const [user, setUser] = useState(initialState);
    useEffect(() => {
        setLoading(true);
        const fetchData = async () => {
            const planList = await getPlanList();
            setPlans(planList);
            const defaultPlan = planList.find((plan) => plan.id === 1); // Carrega todos os planos mas seleciona o plano 1 automaticamente
            setSelectedPlan(defaultPlan ? defaultPlan.id : "");
            setLoading(false);
        };
        fetchData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    /* useEffect(() => {
        setLoading(true);
        const fetchData = async () => {
            const allPlans = await getPlanList();
            const filteredPlans = allPlans.filter((plan) => plan.id === 1); // Filtra o plano 1

            setPlans(filteredPlans);

            // Verifica se o plano filtrado é o 1
            const defaultPlan = filteredPlans.find((plan) => plan.id === 1);
            setSelectedPlan(defaultPlan ? defaultPlan.id : ""); // Define o plano com id 1 como selecionado automaticamente // Filtra, seleciona e exibe somente um plano especifico
            setLoading(false);
        };
        fetchData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); */

    const handleSignUp = async (values) => {
        try {
            await openApi.post("/auth/signup", { ...values, planId: selectedPlan });
            toast.success(i18n.t("signup.toasts.success"));
            history.push("/login");
        } catch (err) {
            toastError(err);
        }
    };

    const getMask = value => {
        if (value && value.length <= 11) {
            return "999.999.999-99";
        }
        return "99.999.999/9999-99";
    };

    return (
        <div className={classes.root}>
            <div className={classes.contentWrapper}>
                <Container component="main" maxWidth="xs">
                    <CssBaseline />
                    <div className={classes.paper}>
                        <img style={{ margin: "0 auto", height: "100%", width: "100%" }} src={logo} alt="Valezap" />
                        <Typography component="h1" variant="h5">
                            {i18n.t("signup.title")}
                        </Typography>
                        <Formik
                            initialValues={user}
                            enableReinitialize={true}
                            validationSchema={UserSchema}
                            onSubmit={(values, actions) => {
                                setTimeout(() => {
                                    handleSignUp(values);
                                    actions.setSubmitting(false);
                                }, 400);
                            }}
                        >
                            {({ touched, errors, isSubmitting, handleChange, handleBlur, handleSubmit, values }) => (
                                <form className={classes.form} onSubmit={handleSubmit}>
                                    <TextField
                                        variant="standard"
                                        size="small"
                                        margin="normal"
                                        color="warning"
                                        required
                                        fullWidth
                                        id="companyName"
                                        label={i18n.t("signup.form.company")}
                                        error={touched.companyName && Boolean(errors.companyName)}
                                        helperText={touched.companyName && errors.companyName}
                                        name="companyName"
                                        autoComplete="companyName"
                                        autoFocus
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.companyName}
                                    />
                                    <TextField
                                        variant="standard"
                                        size="small"
                                        margin="normal"
                                        color="warning"
                                        required
                                        fullWidth
                                        id="name"
                                        label={i18n.t("signup.form.name")}
                                        name="name"
                                        error={touched.name && Boolean(errors.name)}
                                        helperText={touched.name && errors.name}
                                        autoComplete="name"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.name}
                                    />
                                    <TextField
                                        variant="standard"
                                        size="small"
                                        margin="normal"
                                        color="warning"
                                        required
                                        fullWidth
                                        id="email"
                                        label={i18n.t("signup.form.email")}
                                        name="email"
                                        error={touched.email && Boolean(errors.email)}
                                        helperText={touched.email && errors.email}
                                        autoComplete="email"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.email}
                                    />
                                    <TextField
                                        variant="standard"
                                        size="small"
                                        margin="normal"
                                        color="warning"
                                        required
                                        fullWidth
                                        name="password"
                                        error={touched.password && Boolean(errors.password)}
                                        helperText={touched.password && errors.password}
                                        label={i18n.t("signup.form.password")}
                                        id="password"
                                        autoComplete="password"
                                        type={showPassword ? 'text' : 'password'}
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.password}
                                        InputProps={{
                                            endAdornment: (
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        aria-label="toggle password visibility"
                                                        onClick={() => setShowPassword((e) => !e)}
                                                    >
                                                        {showPassword ? <VisibilityOff /> : <Visibility />}
                                                    </IconButton>
                                                </InputAdornment>
                                            )
                                        }}
                                    />
                                    <TextField
                                        variant="standard"
                                        size="small"
                                        margin="normal"
                                        color="warning"
                                        required
                                        fullWidth
                                        id="phone"
                                        label={i18n.t("signup.form.phone")}
                                        name="phone"
                                        inputProps={{
                                            pattern: "[0-9]*", // Permite apenas números
                                        }}
                                        error={touched.phone && Boolean(errors.phone)}
                                        helperText={touched.phone && errors.phone}
                                        autoComplete="phone"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.phone}
                                    />

                                    <TextField
                                        mask={getMask}
                                        variant="standard"
                                        size="small"
                                        margin="normal"
                                        color="warning"
                                        required
                                        fullWidth
                                        id="cpfCnpj"
                                        label="CPF/CNPJ"
                                        name="cpfCnpj"
                                        error={touched.cpfCnpj && Boolean(errors.cpfCnpj)}
                                        helperText={touched.cpfCnpj && errors.cpfCnpj}
                                        autoComplete="cpfCnpj"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        value={values.cpfCnpj}
                                    />
                                    <InputLabel htmlFor="plan-selection"></InputLabel>
                                    <FormControl variant="standard" margin="normal" size="small" required fullWidth>
                                        <InputLabel htmlFor="plan-selection">Planos</InputLabel>
                                        <Select
                                            id="plan-selection"
                                            name="planId"
                                            value={selectedPlan}
                                            onChange={(e) => {
                                                setSelectedPlan(e.target.value);
                                                setUser((prevUser) => ({ ...prevUser, planId: e.target.value }));
                                            }}
                                            onBlur={handleBlur}
                                        >
                                            {plans.map((plan, key) => (
                                                <MenuItem key={key} value={plan.id}>
                                                    {plan.name} - Atendentes: {plan.users} - WhatsApp: {plan.connections} - Filas: {plan.queues} - R$ {plan.amount}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                    <Button
                                        type="submit"
                                        fullWidth
                                        variant="outlined"
                                        color="primary"
                                        className={classes.submit}
                                        disabled={isSubmitting}
                                    >
                                        {i18n.t("signup.buttons.submit")}
                                    </Button>
                                    <Grid container>
                                        <Grid item>
                                            <Link
                                                href="#"
                                                variant="body2"
                                                component={RouterLink}
                                                to="/login"
                                            >
                                                {i18n.t("signup.buttons.login")}
                                            </Link>
                                        </Grid>
                                    </Grid>
                                </form>
                            )}
                        </Formik>
                    </div>
                    <Box mt={5}></Box>
                </Container>
            </div>
        </div>
    );
};

export default SignUp;
